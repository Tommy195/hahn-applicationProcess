import {Router, RouterConfiguration} from 'aurelia-router';
import {PLATFORM} from 'aurelia-framework';

export class App {
  router: Router;

  constructor() {
  }

  configureRouter(config: RouterConfiguration, router: Router) {
    config.title = 'Assets';
    config.options.pushState = true;
    config.options.root = '/';
    config.map([
      { route: '',              moduleId: PLATFORM.moduleName('noselection'),   title: 'Select'},
      { route: 'assets/:id',  moduleId: PLATFORM.moduleName('asset-detail'), name:'assets' },
      { route: 'assets/create',  moduleId: PLATFORM.moduleName('asset-create'), name:'create_assets' }
    ]);

    this.router = router;
  }
}


