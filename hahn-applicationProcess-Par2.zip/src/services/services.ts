import { HttpClient } from "aurelia-http-client";
import { inject } from "aurelia-framework";

import api from '../config/api';
import { Asset } from "model/asset";

@inject(HttpClient)
export class AssetService {
    private http:HttpClient;
    assets: Asset[];

    constructor(http:HttpClient) {
        http.configure(x => x.withBaseUrl(api.dev + '/assets/'));
        this.http = http;
    }

    getAssets() {
        let promise = new Promise((resolve, reject) => {
            this.http
                .get(api.dev + '/assets')
                .then(data => {
                    this.assets = JSON.parse(data.response);
                    resolve(this.assets)
                }).catch(err => reject(err));
        });
        return promise;
    }

    createAsset(asset: Asset) {
        let promise = new Promise((resolve, reject) => {
            this.http
                .post(api.dev + '/assets', asset)
                .then(data => {
                    let newContact = JSON.parse(data.response);
                    resolve(newContact);
                }).catch(err => reject(err));
        });
        return promise;
    }

    getAsset(id: number) {
        let promise = new Promise<Asset>((resolve, reject) => {
            this.http
                .get(api.dev + '/assets/' + id)
                .then(response => {
                    let asset = JSON.parse(response.response);
                    resolve(asset);
                }).catch(err => reject(err))
        });
        return promise;
    }

    deleteAsset(id: number) {
        let promise = new Promise<Asset>((resolve, reject) => {
            this.http
                .delete(api.dev + '/assets/' + id)
                .then(response => {
                    let res = JSON.parse(response.response);
                    resolve(res);
                })
                .catch(err => reject(err));
        });
        return promise;
    }

    updateAsset(asset: Asset) {
        let promise = new Promise<Asset>((resolve, reject) => {
            this.http
                .put(api.dev + '/assets/'+ asset.id, asset)
                .then(response => {
                    let asset = JSON.parse(response.response);
                    resolve(asset);
                }).catch(err => reject(err));
        });
        return promise;
    }
}