import { Asset } from "./model/asset";

export class AssetUpdated {
    asset: Asset;
    constructor(asset) {
      this.asset = asset;
    }
  }
  
  export class AssetViewed {
    asset: Asset;
    constructor(asset) {
      this.asset = asset;
    }
  }

  export class AssetDeleted {
    asset: Asset;
    constructor(asset) {
      this.asset = asset;
    }
  }
  
  export class AssetCreated {
    asset: Asset;
    constructor(asset) {
      this.asset = asset;
    }
  }
    