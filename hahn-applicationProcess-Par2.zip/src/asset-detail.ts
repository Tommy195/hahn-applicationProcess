import {inject} from 'aurelia-framework'
import {EventAggregator} from 'aurelia-event-aggregator'

import {AssetService} from "./services/services";
import {AssetUpdated, AssetCreated, AssetViewed} from './messages'
import {areEqual} from './utility';
import { Asset } from './model/asset';

@inject(EventAggregator, AssetService)
export class AssetDetail {
    private _assetService: AssetService;
    event: any;
    routeConfig: any;
    activeAsset: Asset;
    originalAsset: Asset;

    constructor(eventAggregator, assetService: AssetService) {
        this.event = eventAggregator;
        this._assetService = assetService;
    }

    activate(params, routeConfig) {
        this.routeConfig = routeConfig;
        return this._assetService.getAsset(params.id)
                .then(asset => {
                    this.activeAsset = asset;
                    this.routeConfig.navModel.setTitle(this.activeAsset.assetName);
                    this.originalAsset = asset;
                    this.event.publish(new AssetViewed(this.activeAsset));
                }
            );
      }

    get canSave() {
        return this.activeAsset.assetName;
    }
    
    save(asset: Asset) {
        if(confirm('Are you sure that you want to update this asset?')) {
            console.log(asset.id)
            
            this._assetService
                .updateAsset(asset)
                .then(reponse => {
                    this.event.publish(new AssetUpdated(asset));
                })
                .catch(err => console.log(err));
        }
    }

    canDeactivate() {
        if(!areEqual(this.originalAsset, this.activeAsset)){
            let result = confirm('You have unsaved changes. Are you sure you wish to leave?');
            if(!result) {
                this.event.publish(new AssetViewed(this.activeAsset));
            }
            return result;
        }
        return true;
    }

}