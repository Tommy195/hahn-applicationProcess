export class NoSelection {
    message = "Please Select an Asset.";
}
  
    