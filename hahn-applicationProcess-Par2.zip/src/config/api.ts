export default {
    dev: "http://localhost:5000",
    prod: ""
}