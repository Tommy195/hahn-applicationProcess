import {FrameworkConfiguration} from 'aurelia-framework';
import {LoadingIndicator} from './elements/loading-indicator';

export function configure(config: FrameworkConfiguration) {
  config.globalResources(LoadingIndicator);
  
}
