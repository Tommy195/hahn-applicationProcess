import {inject, NewInstance, autoinject} from 'aurelia-dependency-injection';
import {EventAggregator} from "aurelia-event-aggregator";
import {AssetCreated} from './messages'
import {AssetService} from './services/services';
import { Asset } from 'model/asset';
import { validateTrigger, ValidationController, ValidationControllerFactory, ValidationRules, Validator } from 'aurelia-validation';
import { BootstrapFormRenderer } from 'bootstrap-form-renderer';

@autoinject()
@inject(EventAggregator, AssetService, ValidationControllerFactory, NewInstance.of(ValidationController))
export class CreateAsset {
    _assetService: AssetService;
    _ea: EventAggregator;
    asset: Asset;
    validator: Validator;

    constructor(ea: EventAggregator, assetService: AssetService, validator: Validator, private controller: ValidationController) {
        this._assetService = assetService;
        this._ea = ea;
        this.validator = validator;
        this.controller.validateTrigger = validateTrigger.blur;
        this.controller.addRenderer(new BootstrapFormRenderer());

        ValidationRules
        .ensure((u: Asset) => u.assetName).required().minLength(5).withMessage('Must have at least 5 characters.')
        //.ensure((u: Asset) => u.departmentId.toString()).required().between(1,5).withMessage('Must be a valid department id.')
        .ensure((u: Asset) => u.emailAdressOfDepartment).required().email().withMessage('Must be a valid email.')
        // .ensure((u: Asset) => u.purchaseDate).required().withMessage('Purchased date mus not be older than one year.')
        .equals((u: Asset) => u.broken = true || false).withMessage('Status should not be null.')
        .on(Asset);    
    }

    create() {
        let asset = JSON.parse(JSON.stringify(this.asset));
        this._assetService.createAsset(asset)
            .then(asset => {
                this._ea.publish(new AssetCreated(asset));
            }).catch(err => console.log(err));
    }

    reset() {
        if(confirm('Are you sure that you want to reset this asset?')) {
        }
    }
}

// ValidationRules
// .ensure((u: Asset) => u.assetName).required().minLength(5).withMessage('Must have at least 5 characters.')
// //.ensure((u: Asset) => u.departmentId.toString()).required().between(1,5).withMessage('Must be a valid department id.')
// .ensure((u: Asset) => u.emailAdressOfDepartment).required().email().withMessage('Must be a valid email.')
// // .ensure((u: Asset) => u.purchaseDate).required().withMessage('Purchased date mus not be older than one year.')
// .equals((u: Asset) => u.broken = true || false).withMessage('Status should not be null.')
// .on(Asset);