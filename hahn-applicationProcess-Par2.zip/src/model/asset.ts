export class Asset {
    id: number;
    assetName: string;
    departmentId: number;
    countryOfDepartment: string;
    purchaseDate: Date;
    broken: boolean;
    emailAdressOfDepartment: string;

    constructor(id, assetName, departmentId, countryOfDepartment, emailAdressOfDepartment, purchaseDate, broken) {
      this.id = id;
      this.assetName = assetName;
      this.departmentId = departmentId;
      this.countryOfDepartment = countryOfDepartment;
      this.emailAdressOfDepartment = emailAdressOfDepartment;
      this.purchaseDate = purchaseDate;
      this.broken = broken;
    }
  }